/**
 * Forms Framework Javascript Handling Object
 *	ffPage' namespace
 */

ff.ffPage = (function () {
//privates

var that = { // publics
__ff : true // used to recognize ff'objects
}; // publics' end

return that;

// code's end.
})();
