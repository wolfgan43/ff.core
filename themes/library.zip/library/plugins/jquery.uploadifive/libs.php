<?php
	return array(
		"jquery" => array(
			"all" => array(
				"js_defs" => array(
					"plugins" => array(
						"empty" => true,
						"js_defs" => array(
							'uploadifive' => 
							array (
								'path' => '/themes/library/plugins/jquery.uploadifive',
								'file' => 'jquery.uploadifive.js',
								'index' => 200,
								'css_deps' => 
								array (
									'.style' => 
									array (
										'path' => '/themes/library/plugins/jquery.uploadifive',
										'file' => 'uploadifive.css'
									)
								)
							)
						)
					)
				)
			)
		)
	);