<?php
return array(
	"jquery" => array(
		"all" => array(
			"js_defs" => array(
				"plugins" => array(
					"empty" => true,
					"js_defs" => array(
						"nicescroll" => array(
							"path" => FF_THEME_DIR . "/library/plugins/jquery.nicescroll",
							"file" => "jquery.nicescroll.js",
							"js_defs" => array(
								"observe" => array(
									"path" => FF_THEME_DIR . "/library/plugins/jquery.nicescroll",
									"file" => "jquery.nicescroll.observe.js",
								)
							)
						)
					)
				)
			)
		)
	)
);
