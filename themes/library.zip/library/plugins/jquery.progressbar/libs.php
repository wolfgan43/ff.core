<?php
return array(
	"jquery" => array(
		"all" => array(
			"js_defs" => array(
				"plugins" => array(
					"empty" => true,
					"js_defs" => array(
						"progressbar" => array(
							"path" => FF_THEME_DIR . "/library/plugins/jquery.progressbar",
							"file" => "jquery.progressbar.js"
						)
					)
				)
			)
		)
	)
);
