<?php
return array(
	"jquery" => array(
		"all" => array(
			"js_defs" => array(
				"plugins" => array(
					"js_defs" => array(
						"fancybox" => array(
							"path" => FF_THEME_DIR . "/library/plugins/jquery.fancybox",
							"file" => "jquery.fancybox.js",
							"css_loads" => array(
								".style" => array(
									"path" => FF_THEME_DIR . "/library/plugins/jquery.fancybox",
									"file" => "jquery.fancybox.css"
								)
							)
						)
					)
				)
			)
		)
	)
);
