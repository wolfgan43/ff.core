<?php
return array(
	"jquery" => array(
		"all" => array(
			"js_defs" => array(
				"plugins" => array(
					"empty" => true,
					"js_defs" => array(
						"autogrow-textarea" => array(
							"path" => FF_THEME_DIR . "/library/plugins/jquery.autogrow-textarea",
							"file" => "jquery.autogrow-textarea.js"
						)
					)
				)
			)
		)
	)
);
